import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main(){WidgetsFlutterBinding.ensureInitialized();runApp(const App());}
class App extends StatelessWidget{
  const App({super.key});
  @override Widget build(BuildContext context)=>MaterialApp(
    debugShowCheckedModeBanner:false,
    title:'ONP Bulletin',
    theme:ThemeData(colorScheme:ColorScheme.fromSeed(seedColor:const Color(0xFF00695C)),useMaterial3:true,inputDecorationTheme:const InputDecorationTheme(filled:true)),
    home:const HomeScreen(),
  );
}
