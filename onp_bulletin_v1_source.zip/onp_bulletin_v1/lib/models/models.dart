class BulletinRow {
  final int? id;
  final int? documentId;
  String bulletinNumber;
  String buyer;
  String category;
  String origin;
  String workEnvironment;
  String unit;
  int quantity;
  double unitWeight;
  double unitPrice;
  double totalWeight;
  double value;

  BulletinRow({
    this.id,
    this.documentId,
    this.bulletinNumber = '',
    this.buyer = '',
    this.category = '',
    this.origin = '',
    this.workEnvironment = '',
    this.unit = '',
    this.quantity = 0,
    this.unitWeight = 0,
    this.unitPrice = 0,
    this.totalWeight = 0,
    this.value = 0,
  });

  Map<String, Object?> toMap(int docId) => {
    'document_id': docId,
    'bulletin_number': bulletinNumber,
    'buyer': buyer,
    'category': category,
    'origin': origin,
    'work_environment': workEnvironment,
    'unit': unit,
    'quantity': quantity,
    'unit_weight': unitWeight,
    'unit_price': unitPrice,
    'total_weight': totalWeight,
    'value': value,
  };

  factory BulletinRow.fromMap(Map<String, Object?> m) => BulletinRow(
    id: m['id'] as int?,
    documentId: m['document_id'] as int?,
    bulletinNumber: (m['bulletin_number'] ?? '') as String,
    buyer: (m['buyer'] ?? '') as String,
    category: (m['category'] ?? '') as String,
    origin: (m['origin'] ?? '') as String,
    workEnvironment: (m['work_environment'] ?? '') as String,
    unit: (m['unit'] ?? '') as String,
    quantity: (m['quantity'] as num?)?.toInt() ?? 0,
    unitWeight: (m['unit_weight'] as num?)?.toDouble() ?? 0,
    unitPrice: (m['unit_price'] as num?)?.toDouble() ?? 0,
    totalWeight: (m['total_weight'] as num?)?.toDouble() ?? 0,
    value: (m['value'] as num?)?.toDouble() ?? 0,
  );
}

class BulletinDocument {
  final int? id;
  String boatName;
  String boatNumber;
  DateTime date;
  String periodText;
  String place;
  String imagePath;
  String rawOcr;
  int bulletinCount;
  int crateCount;
  double totalWeight;
  double totalValue;
  List<BulletinRow> rows;

  BulletinDocument({
    this.id,
    required this.boatName,
    this.boatNumber = '',
    required this.date,
    this.periodText = '',
    this.place = '',
    this.imagePath = '',
    this.rawOcr = '',
    this.bulletinCount = 0,
    this.crateCount = 0,
    this.totalWeight = 0,
    this.totalValue = 0,
    this.rows = const [],
  });

  Map<String, Object?> toMap() => {
    'boat_name': boatName,
    'boat_number': boatNumber,
    'document_date': date.toIso8601String(),
    'period_text': periodText,
    'place': place,
    'image_path': imagePath,
    'raw_ocr': rawOcr,
    'bulletin_count': bulletinCount,
    'crate_count': crateCount,
    'total_weight': totalWeight,
    'total_value': totalValue,
  };

  factory BulletinDocument.fromMap(Map<String, Object?> m, {List<BulletinRow> rows = const []}) => BulletinDocument(
    id: m['id'] as int?,
    boatName: (m['boat_name'] ?? '') as String,
    boatNumber: (m['boat_number'] ?? '') as String,
    date: DateTime.tryParse((m['document_date'] ?? '') as String) ?? DateTime.now(),
    periodText: (m['period_text'] ?? '') as String,
    place: (m['place'] ?? '') as String,
    imagePath: (m['image_path'] ?? '') as String,
    rawOcr: (m['raw_ocr'] ?? '') as String,
    bulletinCount: (m['bulletin_count'] as num?)?.toInt() ?? 0,
    crateCount: (m['crate_count'] as num?)?.toInt() ?? 0,
    totalWeight: (m['total_weight'] as num?)?.toDouble() ?? 0,
    totalValue: (m['total_value'] as num?)?.toDouble() ?? 0,
    rows: rows,
  );
}
