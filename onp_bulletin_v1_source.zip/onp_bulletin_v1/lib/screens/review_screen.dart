import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/models.dart';
import '../services/database_service.dart';

class ReviewScreen extends StatefulWidget {
  final BulletinDocument document;
  const ReviewScreen({super.key, required this.document});
  @override State<ReviewScreen> createState()=>_ReviewScreenState();
}
class _ReviewScreenState extends State<ReviewScreen> {
  late final TextEditingController boat = TextEditingController(text: widget.document.boatName);
  late final TextEditingController date = TextEditingController(text: DateFormat('dd/MM/yyyy').format(widget.document.date));
  bool saving=false;

  Future<void> _save() async {
    setState(()=>saving=true);
    widget.document.boatName=boat.text.trim().isEmpty?'Bateau sans nom':boat.text.trim();
    final p=date.text.split('/');
    if(p.length==3) widget.document.date=DateTime.tryParse('${p[2]}-${p[1]}-${p[0]}')??widget.document.date;
    widget.document.totalWeight=widget.document.rows.fold(0,(s,r)=>s+r.totalWeight);
    widget.document.totalValue=widget.document.rows.fold(0,(s,r)=>s+r.value);
    await DatabaseService.instance.saveDocument(widget.document);
    if(mounted) Navigator.pop(context,true);
  }

  @override Widget build(BuildContext context)=>Scaffold(
    appBar: AppBar(title: const Text('مراجعة قبل الحفظ')),
    body: ListView(padding: const EdgeInsets.all(12), children:[
      TextField(controller: boat, decoration: const InputDecoration(labelText:'اسم الباطو', border:OutlineInputBorder())),
      const SizedBox(height:10),
      TextField(controller: date, decoration: const InputDecoration(labelText:'التاريخ DD/MM/YYYY', border:OutlineInputBorder())),
      const SizedBox(height:12),
      Text('السطور المستخرجة: ${widget.document.rows.length}', style:Theme.of(context).textTheme.titleMedium),
      const SizedBox(height:8),
      ...widget.document.rows.asMap().entries.map((e)=>_RowEditor(row:e.value,index:e.key,onDelete:(){setState(()=>widget.document.rows.removeAt(e.key));})),
      OutlinedButton.icon(onPressed:()=>setState(()=>widget.document.rows.add(BulletinRow())), icon:const Icon(Icons.add), label:const Text('إضافة سطر')),
      const SizedBox(height:80),
    ]),
    bottomNavigationBar: SafeArea(child:Padding(padding:const EdgeInsets.all(12),child:FilledButton.icon(onPressed:saving?null:_save,icon:saving?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.save),label:const Text('حفظ الوثيقة')))),
  );
}

class _RowEditor extends StatelessWidget {
  final BulletinRow row; final int index; final VoidCallback onDelete;
  const _RowEditor({required this.row,required this.index,required this.onDelete});
  InputDecoration d(String s)=>InputDecoration(labelText:s,isDense:true,border:const OutlineInputBorder());
  @override Widget build(BuildContext context)=>Card(child:Padding(padding:const EdgeInsets.all(10),child:Column(children:[
    Row(children:[Expanded(child:Text('السطر ${index+1}',style:const TextStyle(fontWeight:FontWeight.bold))),IconButton(onPressed:onDelete,icon:const Icon(Icons.delete_outline))]),
    TextFormField(initialValue:row.bulletinNumber,onChanged:(v)=>row.bulletinNumber=v,decoration:d('رقم Bulletin')),
    const SizedBox(height:8),TextFormField(initialValue:row.buyer,onChanged:(v)=>row.buyer=v,decoration:d('المشتري')),
    const SizedBox(height:8),Row(children:[Expanded(child:TextFormField(initialValue:'${row.quantity}',keyboardType:TextInputType.number,onChanged:(v)=>row.quantity=int.tryParse(v)??0,decoration:d('العدد'))),const SizedBox(width:8),Expanded(child:TextFormField(initialValue:'${row.unitPrice}',keyboardType:TextInputType.number,onChanged:(v)=>row.unitPrice=double.tryParse(v.replaceAll(',','.'))??0,decoration:d('Prix U')))]),
    const SizedBox(height:8),Row(children:[Expanded(child:TextFormField(initialValue:'${row.totalWeight}',keyboardType:TextInputType.number,onChanged:(v)=>row.totalWeight=double.tryParse(v.replaceAll(',','.'))??0,decoration:d('Poids total'))),const SizedBox(width:8),Expanded(child:TextFormField(initialValue:'${row.value}',keyboardType:TextInputType.number,onChanged:(v)=>row.value=double.tryParse(v.replaceAll(',','.'))??0,decoration:d('Valeur')))]),
  ])));
}
