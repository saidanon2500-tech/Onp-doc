import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/models.dart';
import '../services/export_service.dart';

class DocumentScreen extends StatelessWidget {
  final BulletinDocument document;
  const DocumentScreen({super.key,required this.document});
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:Text(document.boatName),actions:[
      IconButton(tooltip:'CSV',onPressed:()=>ExportService().shareCsv(document),icon:const Icon(Icons.table_view)),
      IconButton(tooltip:'طباعة PDF',onPressed:()=>ExportService().printPdf(document),icon:const Icon(Icons.print)),
    ]),
    body:ListView(padding:const EdgeInsets.all(12),children:[
      Text(DateFormat('dd/MM/yyyy').format(document.date),style:Theme.of(context).textTheme.titleLarge),
      Text('Bulletins: ${document.bulletinCount} • Caisses: ${document.crateCount}'),
      Text('Poids total: ${document.totalWeight.toStringAsFixed(2)} • Valeur: ${document.totalValue.toStringAsFixed(2)}'),
      const SizedBox(height:12),
      if(document.imagePath.isNotEmpty && File(document.imagePath).existsSync()) ClipRRect(borderRadius:BorderRadius.circular(12),child:Image.file(File(document.imagePath),height:220,fit:BoxFit.contain)),
      const SizedBox(height:12),
      SingleChildScrollView(scrollDirection:Axis.horizontal,child:DataTable(columns:const[
        DataColumn(label:Text('Bulletin')),DataColumn(label:Text('Acheteur')),DataColumn(label:Text('Nbre')),DataColumn(label:Text('Prix U')),DataColumn(label:Text('Poids total')),DataColumn(label:Text('Valeur')),
      ],rows:document.rows.map((r)=>DataRow(cells:[DataCell(Text(r.bulletinNumber)),DataCell(Text(r.buyer)),DataCell(Text('${r.quantity}')),DataCell(Text('${r.unitPrice}')),DataCell(Text('${r.totalWeight}')),DataCell(Text('${r.value}'))])).toList())),
    ]),
  );
}
