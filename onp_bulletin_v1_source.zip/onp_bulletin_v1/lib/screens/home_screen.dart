import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import '../models/models.dart';
import '../services/database_service.dart';
import '../services/ocr_service.dart';
import '../services/parser_service.dart';
import 'review_screen.dart';
import 'document_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool loading = true;
  List<BulletinDocument> docs = [];

  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    docs = await DatabaseService.instance.listDocuments();
    if (mounted) setState(() => loading = false);
  }

  Future<void> _scan(ImageSource source) async {
    final x = await ImagePicker().pickImage(source: source, imageQuality: 95);
    if (x == null || !mounted) return;
    showDialog(context: context, barrierDismissible: false, builder: (_) => const AlertDialog(content: Row(children:[CircularProgressIndicator(), SizedBox(width:16), Expanded(child:Text('جاري قراءة الوثيقة...'))])));
    try {
      final ocr = await OcrService().scan(x.path);
      final draft = BulletinParser().parse(ocr, x.path);
      if (!mounted) return;
      Navigator.pop(context);
      final saved = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => ReviewScreen(document: draft)));
      if (saved == true) _load();
    } catch (e) {
      if (!mounted) return;
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('فشل استخراج الوثيقة: $e')));
    }
  }

  @override Widget build(BuildContext context) {
    final grouped = <String, List<BulletinDocument>>{};
    for (final d in docs) { grouped.putIfAbsent(d.boatName, () => []).add(d); }
    return Scaffold(
      appBar: AppBar(title: const Text('أرشيف البواخر الذكي')),
      body: loading ? const Center(child: CircularProgressIndicator()) : grouped.isEmpty
        ? const Center(child: Text('لا توجد وثائق بعد. ارفع أول صورة.'))
        : ListView(padding: const EdgeInsets.all(12), children: grouped.entries.map((e) {
            final years = e.value.map((d) => d.date.year).toSet().toList()..sort((a,b)=>b.compareTo(a));
            return Card(child: ExpansionTile(
              title: Text(e.key, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text('${e.value.length} وثيقة • ${years.join('، ')}'),
              children: years.map((year) => ExpansionTile(
                title: Text('سنة $year'),
                children: e.value.where((d)=>d.date.year==year).map((d)=>ListTile(
                  title: Text(DateFormat('dd/MM/yyyy').format(d.date)),
                  subtitle: Text('الصناديق: ${d.crateCount} • الوزن: ${d.totalWeight.toStringAsFixed(2)} • القيمة: ${d.totalValue.toStringAsFixed(2)}'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: ()=>Navigator.push(context, MaterialPageRoute(builder:(_)=>DocumentScreen(document:d))),
                )).toList(),
              )).toList(),
            ));
          }).toList()),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => showModalBottomSheet(context: context, builder: (_) => SafeArea(child: Wrap(children: [
          ListTile(leading: const Icon(Icons.photo_camera), title: const Text('التقاط صورة'), onTap:(){Navigator.pop(context); _scan(ImageSource.camera);}),
          ListTile(leading: const Icon(Icons.photo_library), title: const Text('اختيار من الهاتف'), onTap:(){Navigator.pop(context); _scan(ImageSource.gallery);}),
        ]))),
        icon: const Icon(Icons.document_scanner), label: const Text('رفع وثيقة'),
      ),
    );
  }
}
