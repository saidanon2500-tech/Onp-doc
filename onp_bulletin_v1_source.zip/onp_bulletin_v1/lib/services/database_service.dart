import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/models.dart';

class DatabaseService {
  DatabaseService._();
  static final instance = DatabaseService._();
  Database? _db;

  Future<Database> get db async => _db ??= await _open();

  Future<Database> _open() async {
    final path = join(await getDatabasesPath(), 'onp_bulletins_v1.db');
    return openDatabase(path, version: 1, onCreate: (db, _) async {
      await db.execute('''CREATE TABLE documents(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        boat_name TEXT NOT NULL,
        boat_number TEXT NOT NULL DEFAULT '',
        document_date TEXT NOT NULL,
        period_text TEXT NOT NULL DEFAULT '',
        place TEXT NOT NULL DEFAULT '',
        image_path TEXT NOT NULL DEFAULT '',
        raw_ocr TEXT NOT NULL DEFAULT '',
        bulletin_count INTEGER NOT NULL DEFAULT 0,
        crate_count INTEGER NOT NULL DEFAULT 0,
        total_weight REAL NOT NULL DEFAULT 0,
        total_value REAL NOT NULL DEFAULT 0
      )''');
      await db.execute('''CREATE TABLE rows(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        document_id INTEGER NOT NULL,
        bulletin_number TEXT NOT NULL DEFAULT '',
        buyer TEXT NOT NULL DEFAULT '',
        category TEXT NOT NULL DEFAULT '',
        origin TEXT NOT NULL DEFAULT '',
        work_environment TEXT NOT NULL DEFAULT '',
        unit TEXT NOT NULL DEFAULT '',
        quantity INTEGER NOT NULL DEFAULT 0,
        unit_weight REAL NOT NULL DEFAULT 0,
        unit_price REAL NOT NULL DEFAULT 0,
        total_weight REAL NOT NULL DEFAULT 0,
        value REAL NOT NULL DEFAULT 0,
        FOREIGN KEY(document_id) REFERENCES documents(id) ON DELETE CASCADE
      )''');
      await db.execute('CREATE INDEX idx_docs_boat_date ON documents(boat_name, document_date)');
      await db.execute('CREATE INDEX idx_rows_doc ON rows(document_id)');
    });
  }

  Future<int> saveDocument(BulletinDocument doc) async {
    final database = await db;
    return database.transaction((txn) async {
      final id = await txn.insert('documents', doc.toMap());
      for (final row in doc.rows) {
        await txn.insert('rows', row.toMap(id));
      }
      return id;
    });
  }

  Future<List<BulletinDocument>> listDocuments() async {
    final database = await db;
    final maps = await database.query('documents', orderBy: 'document_date DESC');
    return Future.wait(maps.map((m) async {
      final rowMaps = await database.query('rows', where: 'document_id = ?', whereArgs: [m['id']], orderBy: 'id');
      return BulletinDocument.fromMap(m, rows: rowMaps.map(BulletinRow.fromMap).toList());
    }));
  }

  Future<void> deleteDocument(int id) async {
    final database = await db;
    await database.transaction((txn) async {
      await txn.delete('rows', where: 'document_id = ?', whereArgs: [id]);
      await txn.delete('documents', where: 'id = ?', whereArgs: [id]);
    });
  }
}
