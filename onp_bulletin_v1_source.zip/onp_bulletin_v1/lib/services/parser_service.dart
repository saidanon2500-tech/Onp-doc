import '../models/models.dart';
import 'ocr_service.dart';

class BulletinParser {
  BulletinDocument parse(OcrResultData ocr, String imagePath) {
    final text = ocr.text.replaceAll('\r', ' ');
    final boat = _first(text, [
      RegExp(r'Bateau\s*[:\-]?\s*[^\n]*?\b([A-Z0-9][A-Z0-9 ]{2,})', caseSensitive: false),
      RegExp(r'\b(EL\s+[A-Z0-9 ]+\d|NOUR\s+[A-Z0-9 ]+\d)\b', caseSensitive: false),
    ]) ?? 'Bateau sans nom';
    final dateText = _first(text, [RegExp(r'(\d{2}/\d{2}/\d{4})')]);
    final date = _date(dateText) ?? DateTime.now();
    final period = _first(text, [RegExp(r'P[eé]riode\s+du\s+([^\n]+)', caseSensitive: false)]) ?? '';
    final bulletins = _numberAfter(text, RegExp(r'nbr\s+des\s+Bulletin[^\d]*(\d+)', caseSensitive: false));
    final crates = _numberAfter(text, RegExp(r'nbr\s+des\s+Caisses[^\d]*(\d+)', caseSensitive: false));

    final rows = _parseRowsFromLines(text);
    final totalWeight = rows.fold<double>(0, (s, r) => s + r.totalWeight);
    final totalValue = rows.fold<double>(0, (s, r) => s + r.value);
    return BulletinDocument(
      boatName: boat.trim().replaceAll(RegExp(r'\s+'), ' '),
      date: date,
      periodText: period,
      imagePath: imagePath,
      rawOcr: text,
      bulletinCount: bulletins ?? rows.length,
      crateCount: crates ?? rows.fold(0, (s, r) => s + r.quantity),
      totalWeight: totalWeight,
      totalValue: totalValue,
      rows: rows,
    );
  }

  List<BulletinRow> _parseRowsFromLines(String text) {
    final lines = text.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
    final rows = <BulletinRow>[];
    for (final line in lines) {
      final bulletin = RegExp(r'\b(\d{8,})\b').firstMatch(line);
      if (bulletin == null) continue;
      final nums = RegExp(r'\d+(?:[.,]\d+)?').allMatches(line).map((m) => _d(m.group(0)!)).toList();
      if (nums.length < 4) continue;
      final number = bulletin.group(1)!;
      final buyerPart = line.substring(line.indexOf(number) + number.length).replaceAll(RegExp(r'\d+(?:[.,]\d+)?'), ' ').replaceAll(RegExp(r'\s+'), ' ').trim();
      final unitPrice = nums.length >= 4 ? nums[nums.length - 4] : 0;
      final totalWeight = nums.length >= 2 ? nums[nums.length - 2] : 0;
      final value = nums.isNotEmpty ? nums.last : 0;
      final qty = nums.length >= 5 ? nums[nums.length - 5].round() : 1;
      rows.add(BulletinRow(
        bulletinNumber: number,
        buyer: buyerPart,
        quantity: qty,
        unitPrice: unitPrice,
        totalWeight: totalWeight,
        value: value,
      ));
    }
    return rows;
  }

  String? _first(String text, List<RegExp> patterns) {
    for (final p in patterns) {
      final m = p.firstMatch(text);
      if (m != null) return m.group(1) ?? m.group(0);
    }
    return null;
  }

  int? _numberAfter(String text, RegExp p) => int.tryParse(p.firstMatch(text)?.group(1) ?? '');
  DateTime? _date(String? s) {
    if (s == null) return null;
    final p = s.split('/');
    if (p.length != 3) return null;
    return DateTime.tryParse('${p[2]}-${p[1]}-${p[0]}');
  }
  double _d(String s) => double.tryParse(s.replaceAll(' ', '').replaceAll(',', '.')) ?? 0;
}
