import 'dart:io';
import 'package:csv/csv.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';
import '../models/models.dart';

class ExportService {
  List<List<Object?>> _table(BulletinDocument d) => [
    ['Bulletin', 'Acheteur', 'Catégorie', 'Origine', 'Environnement', 'Unité', 'Nbre', 'Poids U', 'Prix U', 'Poids total', 'Valeur'],
    ...d.rows.map((r) => [r.bulletinNumber, r.buyer, r.category, r.origin, r.workEnvironment, r.unit, r.quantity, r.unitWeight, r.unitPrice, r.totalWeight, r.value]),
  ];

  Future<void> shareCsv(BulletinDocument d) async {
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/${_safe(d.boatName)}_${DateFormat('yyyyMMdd').format(d.date)}.csv');
    await file.writeAsString(const ListToCsvConverter().convert(_table(d)));
    await Share.shareXFiles([XFile(file.path)]);
  }

  Future<void> printPdf(BulletinDocument d) async {
    final doc = pw.Document();
    doc.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4.landscape,
      build: (_) => [
        pw.Text(d.boatName, style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
        pw.Text(DateFormat('dd/MM/yyyy').format(d.date)),
        pw.SizedBox(height: 12),
        pw.TableHelper.fromTextArray(data: _table(d), headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold), cellStyle: const pw.TextStyle(fontSize: 7)),
        pw.SizedBox(height: 10),
        pw.Text('Poids total: ${d.totalWeight.toStringAsFixed(2)}    Valeur totale: ${d.totalValue.toStringAsFixed(2)}'),
      ],
    ));
    await Printing.layoutPdf(onLayout: (_) => doc.save());
  }

  String _safe(String s) => s.replaceAll(RegExp(r'[^A-Za-z0-9_-]'), '_');
}
