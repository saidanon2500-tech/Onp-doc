import 'dart:io';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

class OcrWord {
  final String text;
  final double left, top, right, bottom;
  const OcrWord(this.text, this.left, this.top, this.right, this.bottom);
}

class OcrResultData {
  final String text;
  final List<OcrWord> words;
  const OcrResultData(this.text, this.words);
}

class OcrService {
  Future<OcrResultData> scan(String imagePath) async {
    if (!await File(imagePath).exists()) throw StateError('Image not found');
    final recognizer = TextRecognizer(script: TextRecognitionScript.latin);
    try {
      final result = await recognizer.processImage(InputImage.fromFilePath(imagePath));
      final words = <OcrWord>[];
      for (final block in result.blocks) {
        for (final line in block.lines) {
          for (final e in line.elements) {
            final b = e.boundingBox;
            words.add(OcrWord(e.text, b.left, b.top, b.right, b.bottom));
          }
        }
      }
      return OcrResultData(result.text, words);
    } finally {
      await recognizer.close();
    }
  }
}
